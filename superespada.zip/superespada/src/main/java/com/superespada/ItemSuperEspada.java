package com.superespada;

import java.util.List;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;

public class ItemSuperEspada extends ItemSword {

    private static final double RAIO = 128.0D;

    public ItemSuperEspada(ToolMaterial material) {
        super(material);
        this.setMaxDamage(0); // indestrutivel
    }

    @Override
    public boolean hitEntity(ItemStack stack, EntityLivingBase alvo, EntityLivingBase jogador) {
        alvo.setFire(10);
        alvo.addPotionEffect(new PotionEffect(Potion.wither.id, 100, 2));
        alvo.addPotionEffect(new PotionEffect(Potion.moveSlowdown.id, 60, 3));
        jogador.heal(2.0F);

        // Mata tambem jogadores no criativo (dano de "void" ignora o modo criativo)
        if (alvo instanceof EntityPlayer) {
            alvo.attackEntityFrom(DamageSource.outOfWorld, Float.MAX_VALUE);
        }
        return true;
    }

    // Habilidade: botao direito deleta todos os mobs em 128 blocos
    @Override
    public ItemStack onItemRightClick(ItemStack stack, World world, EntityPlayer jogador) {
        if (!world.isRemote) {
            AxisAlignedBB area = AxisAlignedBB.getBoundingBox(
                    jogador.posX - RAIO, jogador.posY - RAIO, jogador.posZ - RAIO,
                    jogador.posX + RAIO, jogador.posY + RAIO, jogador.posZ + RAIO);
            List lista = world.getEntitiesWithinAABB(EntityLiving.class, area);
            int total = 0;
            for (Object o : lista) {
                Entity e = (Entity) o;
                if (e != jogador && !(e instanceof EntityPlayer)) {
                    e.setDead(); // remove/deleta a entidade
                    total++;
                }
            }
            jogador.addChatMessage(new ChatComponentText("Mobs deletados: " + total));
        }
        return stack;
    }

    @Override
    public boolean hasEffect(ItemStack stack) {
        return true; // brilho de encantamento
    }
}
