package com.superespada;

import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.common.registry.GameRegistry;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraftforge.common.util.EnumHelper;

@Mod(modid = SuperEspadaMod.MODID, name = "Super Espada", version = "1.0")
public class SuperEspadaMod {
    public static final String MODID = "superespada";

    // harvestLevel, durabilidade, eficiencia, dano extra, encantabilidade
    public static final Item.ToolMaterial MATERIAL =
            EnumHelper.addToolMaterial("SUPERESPADA", 3, 5000, 12.0F, 1.0E30F, 25);

    public static Item superEspada;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent e) {
        superEspada = new ItemSuperEspada(MATERIAL)
                .setUnlocalizedName("super_espada")
                .setTextureName(MODID + ":super_espada")
                .setCreativeTab(CreativeTabs.tabCombat);
        GameRegistry.registerItem(superEspada, "super_espada");
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent e) {
        // Receita: 2 blocos de diamante, 2 estrelas do Nether, 1 graveto
        GameRegistry.addRecipe(new ItemStack(superEspada),
                "DN",
                "DN",
                "S ",
                'D', Blocks.diamond_block,
                'N', Items.nether_star,
                'S', Items.stick);
    }
}
